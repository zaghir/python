# -*- coding: utf-8 -*-
"""

@author: abhilash
"""

import cv2

#printing the opencv version
print(cv2.__version__)